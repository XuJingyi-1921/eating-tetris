﻿//   ********************************************************************************					  
//  						              *										
//   *********************************************************************************

//游戏的总管理
using UnityEngine;

public class GameManager : MonoBehaviour
{
	public bool isGameActive;
    public SnakeControl snakeControl; //让这个脚本持有一个引用
    public Transform blockHolder;
    public Transform currentStar; //持有一个对当前星星的引用 用来判断蛇头的位置是否xxx
    public PlayerStats stats;

    public Vector3 inputDir = Vector3.right;
    public Vector3 lastDir = Vector3.right;  
    //如果在下一次移动之前输入了多个方向，就只记录最后一个 而且不能和上一次移动的方向相反

    void Awake()
	{
        Screen.SetResolution(480, 860, false);
		isGameActive = false;
	}

	private _StatesBase currentState;
	public _StatesBase State
	{
		get { return currentState; }
	}

    public Vector3 InputDir { get => inputDir; set => inputDir = value; }

    //改变这个 current game的状态
    public void SetState(System.Type newStateType)
	{
		if (currentState != null)
		{
			currentState.OnDeactivate();
		}

		currentState = GetComponentInChildren(newStateType) as _StatesBase;
		if (currentState != null)
		{
			currentState.OnActivate();
		}
	}

	void Update() 
	{
		if (currentState != null)
		{
			currentState.OnUpdate(); //更新
		}
	}

	void Start()
	{
		SetState(typeof(MenuState));  //先进入菜单的状态
	}


}