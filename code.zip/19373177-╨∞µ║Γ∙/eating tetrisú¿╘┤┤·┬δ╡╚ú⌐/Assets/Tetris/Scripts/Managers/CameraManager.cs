﻿//  //   ********************************************************************************					  
//   *********************************************************************************

using UnityEngine;
using System.Collections;
using DG.Tweening;

public class TestCamera : MonoBehaviour
//这是用来设置导出之后的宽高比的代码 但是好像失败了
//来自https://www.jianshu.com/p/95cb4621206e
{
    const float devHeight = 16.0f; //设计的尺寸高度
    const float devWidth = 9.0f; //设计的尺寸宽度

    void Start()
    {
        float screenHeight = Screen.height; //获取屏幕宽度
        Debug.Log("screenHeight = " + screenHeight);

        float orthographicSize = this.GetComponent<Camera>().orthographicSize;
        //拿到相机的正交属性设置摄像机大小

        float aspectRatio = Screen.width * 1.0f / Screen.height; //得到宽高比
        //实际的宽高比和摄像机的orthographicSize值来计算出摄像机的宽度值

        float cameraWidth = orthographicSize * 2 * aspectRatio;
        Debug.Log("cameraWidth = " + cameraWidth);

        if (cameraWidth < devWidth) //如果摄像机宽度小于设计的尺寸宽度
        {
            orthographicSize = devWidth / (2 * aspectRatio);
            //将尺寸宽度/2倍的宽高比 = 相机的大小
            Debug.Log("new orthographicSize = " + orthographicSize);
            this.GetComponent<Camera>().orthographicSize = orthographicSize;
            //将这个摄像机的大小赋值回摄像机属性

        }

    }
}


public class CameraManager : MonoBehaviour {

	public Camera main;
    //定义主界面大小  每次调用的时候就是按这个大小来弄出主界面
    private float _mainMenuSize = 13.5f;
    private float _inGameSize = 11f;

    [HideInInspector]
	public CameraShake shaker;

	void Awake()
	{
		shaker = main.gameObject.GetComponent<CameraShake> ();
	}

    public void ZoomIn()
    {
        if (main.orthographicSize != _inGameSize)
        {
            main.DOOrthoSize(_inGameSize, 1f).SetEase(Ease.OutCubic).OnComplete(() =>
             {
                 StartCoroutine(StartGamePlay());
             });
        }
        else
        {
            Managers.Spawner.Spawn();
            Managers.Game.isGameActive = true;
        }
    }

    public void ZoomOut()
    {
        if (main.orthographicSize != _mainMenuSize)
            main.DOOrthoSize(_mainMenuSize, 1f).SetEase(Ease.OutCubic); ;
    }

    IEnumerator StartGamePlay()
    {
        yield return new WaitForEndOfFrame();

        if (!Managers.Game.isGameActive)
        {
            Managers.Spawner.Spawn();
            Managers.Game.isGameActive = true;
        }
        yield break;
    }



}
