﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScreenManager : MonoBehaviour
{
    private void Update()
    {
        if (Input.GetKey(KeyCode.Escape)) //按esc退出全屏
        {
            Screen.fullScreen=false; //退出全屏
        }
        if (Input.GetKey(KeyCode.B)) //设置全屏
        {
            Screen.SetResolution(1920, 1080, true);
        }
        if (Input.GetKey(KeyCode.C))
        {
            Screen.SetResolution(Screen.width, Screen.height, true);
        }
        if (Input.GetKey(KeyCode.A)) //按A全屏
        {
            Resolution[] resolutions = Screen.resolutions; //获取设置当前屏幕分辨
            Screen.SetResolution(resolutions[resolutions.Length - 1].width, resolutions[resolutions.Length - 1].height, true);
            //设置当前分辨
            Screen.fullScreen = true;//设置成全屏

        }
       
    }
}