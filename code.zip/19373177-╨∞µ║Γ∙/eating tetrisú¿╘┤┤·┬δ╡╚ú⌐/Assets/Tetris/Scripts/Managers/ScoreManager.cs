﻿//  //   ********************************************************************************					  
//    XuJingyi  email: 2123373772@qq.com				分数控制				              *										
//   *********************************************************************************


using UnityEngine;

public class ScoreManager : MonoBehaviour {

	public int currentScore=0;
	public int highScore;

    void Awake()
    {
        if (Managers.Game.stats.highScore != 0)
        {
            highScore = Managers.Game.stats.highScore;
            Managers.UI.inGameUI.UpdateScoreUI();  //在界面上更新
        }
        else
        {
            highScore = 0;
            Managers.UI.inGameUI.UpdateScoreUI(); 
        }
    }

	public void OnScore(int scoreIncreaseAmount) //增加分数
	{	
		currentScore += scoreIncreaseAmount;  //设置成都是一分一分地加
        CheckHighScore();
        Managers.UI.inGameUI.UpdateScoreUI();  //更新界面
        Managers.Game.stats.totalScore += scoreIncreaseAmount;
    }

    public void CheckHighScore() //检查是否要更改最高分
    {
        if (highScore < currentScore)
        {
            highScore = currentScore;
        }
    }

    public void ResetScore()  //重新设置分数
    {
        currentScore = 0;
        highScore = Managers.Game.stats.totalScore;
        Managers.UI.inGameUI.UpdateScoreUI();
    }

}
