﻿//  //   ********************************************************************************					  				              *										
//孵化管理   每次方块掉下去之后要重新生成一个俄罗斯蛇

using UnityEngine;

public class SpawnManager : MonoBehaviour {

    public GameObject snake;  //只有两个gameobject 蛇和心
    public GameObject star;

    public void Spawn() //不需要俄罗斯方块的随机 只要生成蛇和心
	{
        //把父亲都指定为blockholder，游戏重新开始时自动清理
        SpawnSnake();
        SpawnStar();
    }

    private void SpawnSnake() //孵化蛇
    {
        Managers.Game.snakeControl = Instantiate(snake, Managers.Game.blockHolder).GetComponent<SnakeControl>();
        //Instantiate：克隆原始物体并且设置位置，角度。
        //这里要定义它的父亲
        Managers.Game.inputDir = Vector3.right; //最开始的方向都是向右
        Managers.Game.lastDir = Vector3.right; //最后一次移动  自然也是向右
        Managers.Input.isActive = true;//这里把用户控制开起来，因为吃到星星之后被我们关掉了
    }

    private void SpawnStar()  //孵化心
    {
        if (!Managers.Grid.CanBePlaceStar(15)) 
            //如果最上面一行都不能孵化 说明都填满了 游戏结束
        {
            Managers.Game.SetState(typeof(GameOverState));
            return;
        }

        int y = Random.Range(2, Constants.CURRENT_ROW - 1); //不在最上和最下生成
        if (!Managers.Grid.CanBePlaceStar(14))
            y = 15;
        else
        {
            while(!Managers.Grid.CanBePlaceStar(y)) //一直到一个合理的y为止
                y = Random.Range(y+1, Constants.CURRENT_ROW - 1);
        }
        int x = Random.Range(0, 10);
        Managers.Game.currentStar = Instantiate(star, new Vector3(x, y), Quaternion.identity, Managers.Game.blockHolder).transform;

    }
}
//50 lines