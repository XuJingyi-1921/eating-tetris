﻿//   ********************************************************************************					  
//   *XuJingYi  email:2123373772@qq.com								              *										
//   *********************************************************************************

using UnityEngine;
//using System.Collections;

public enum InputMethod
{
    KeyboardInput,   //键盘 鼠标  触屏  操作都可以
    MouseInput, 
    TouchInput
}

public class PlayerInputManager : MonoBehaviour
{
    public bool isActive;
    public InputMethod inputType;

    void Awake()
    {

    }

    void Update()
    {
        if (isActive)
        {
            if (inputType == InputMethod.KeyboardInput)
                KeyboardInput();
            //else if (inputType == InputMethod.TouchInput)
               // TouchInput();
        }
    }

    #region KEYBOARD
    void KeyboardInput() //控制键盘的四个方向的输入
    {
        if (Input.GetKeyDown(KeyCode.UpArrow) && Managers.Game.lastDir != Vector3.down)
            Managers.Game.inputDir = Vector3.up;
        else if (Input.GetKeyDown(KeyCode.DownArrow) && Managers.Game.lastDir != Vector3.up)
            Managers.Game.inputDir = Vector3.down;
        else if (Input.GetKeyDown(KeyCode.LeftArrow) && Managers.Game.lastDir != Vector3.right)
            Managers.Game.inputDir = Vector3.left ;
        else if (Input.GetKeyDown(KeyCode.RightArrow) && Managers.Game.lastDir != Vector3.left)
            Managers.Game.inputDir = Vector3.right;
    }
    #endregion

    #region MOUSE
    Vector2 _startPressPosition;
    Vector2 _endPressPosition;
    Vector2 _currentSwipe;
    float _buttonDownPhaseStart;
    public float tapInterval;

 
    #endregion

    #region TOUCH
    /*void TouchInput()
    {
        if (Event.current.type == EventType.MouseDown)
        {
            _startPressPosition = Event.current.mousePosition;
        }
        if (Event.current.type == EventType.MouseUp)
        {
            curPos = Event.current.mousePosition;
            float x = curPos.x - _startPressPosition.x;
        }
    }*/
    #endregion

}