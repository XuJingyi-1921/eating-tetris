﻿//这是控制格子 grid 的代码
using UnityEngine;
using System.Collections;


[System.Serializable]
public class Column //总共20行
{
    public Transform[] row = new Transform[20];
}

public class GridManager : MonoBehaviour
{
    public Column[] gameGridcol = new Column[10];

    public bool InsideBorder(Vector2 pos) //判断是否在边界内
        //俄罗斯方块不会向上移动，所以这里多写一个判断  上面也可能出界
    {
        return ((int)pos.x >= 0 && (int)pos.x < 10 && (int)pos.y >= 0&& (int)pos.y<Constants.CURRENT_ROW);
    }

    public void PlaceShape() //把俄罗斯蛇放在最开始的位置
    {
        int y = 0;

        StartCoroutine(DeleteRows(y));

    }

    IEnumerator DeleteRows(int k)  //判断是否要删除当前行
    {
        for (int y = k; y < Constants.CURRENT_ROW; ++y)//只检测到当前行数
        {
            if (IsRowFull(y))
            {
                DeleteRow(y);
                DecreaseRowsAbove(y + 1);
                --y;
                Managers.Audio.PlayLineClearSound();
                yield return new WaitForSeconds(0.8f);
            }
        }     
        
        foreach (Transform t in Managers.Game.blockHolder)
            //foreach列举出集合中的所有元素
            //遍历数组：foreach（type objName in collection/Array）
            if (t.childCount <= 1)
            {
                Destroy(t.gameObject);
            }

       
        Managers.Spawner.Spawn();

        yield break;
    }

    public bool IsRowFull(int y)  //判断这行是否满
    {
        for (int x = 0; x < 10; ++x)
            if (gameGridcol[x].row[y] == null)
                return false;
        return true;
    }

    public void DeleteRow(int y)  //删除当前行
    {
        Managers.Score.OnScore(5);  //吃到星星的分数是1，这里消除一行的分数也是1 
        for (int x = 0; x < 10; ++x)
        {
            Destroy(gameGridcol[x].row[y].gameObject);
            gameGridcol[x].row[y] = null;
        }
    }

    public void DecreaseRowsAbove(int y) //清除y之上的行
    {
        for (int i = y; i < Constants.CURRENT_ROW; ++i)
            DecreaseRow(i);
    }

    public void DecreaseRow(int y)
    {
        for (int x = 0; x < 10; ++x)
        {
            if (gameGridcol[x].row[y] != null)
            {
                // 将一行向下移
                gameGridcol[x].row[y - 1] = gameGridcol[x].row[y];
                gameGridcol[x].row[y] = null;

                //更新块的位置
                gameGridcol[x].row[y - 1].position += new Vector3(0, -1, 0);
            }
        }
    }

    public bool IsValidGridPosition(Transform obj) //当前格子位置是否合法
    {
        foreach (Transform child in obj)
        {
            if (child.gameObject.tag.Equals("Block"))
            {
                Vector2 v = Vector2Extension.roundVec2(child.position);

                if (!InsideBorder(v))  //不在边界内
                {
                    return false;
                }

            
                //在块边界上的  不是同一组的一部分
                if (gameGridcol[(int)v.x].row[(int)v.y] != null &&
                    gameGridcol[(int)v.x].row[(int)v.y].parent != obj)
                    return false;
            }
        }
        return true;
    }
     
    public void UpdateGrid(Transform obj)  //更新当前格子上的状态
    { 
        for (int y = 0; y < Constants.CURRENT_ROW; y++) 
            //这里只检测到当前有的行数 current row
        {
            for (int x = 0; x < 10; x++)
            {
                if (gameGridcol[x].row[y] != null)
                {
                    if (gameGridcol[x].row[y].parent == obj)
                        gameGridcol[x].row[y] = null;
                }
            }
        }

        foreach (Transform child in obj)
        {
            if (child.gameObject.tag.Equals("Block"))
            {
                Vector2 v = Vector2Extension.roundVec2(child.position);
                gameGridcol[(int)v.x].row[(int)v.y] = child;
            }
        }
    }

    public void ClearBoard()
    {
        for (int y = 0; y < Constants.CURRENT_ROW; y++)
            //这里也只用检测到当前行数
        {
            for (int x = 0; x < 10; x++)
            {
                if (gameGridcol[x].row[y] != null)
                {
                    Destroy(gameGridcol[x].row[y].gameObject);
                    gameGridcol[x].row[y] = null;
                }
            }
        }

        foreach (Transform t in Managers.Game.blockHolder)
            Destroy(t.gameObject);
    }

    //写一个函数检测是否能用来放置星星
    public bool CanBePlaceStar(int y) //传进来的是行数
    {
        for(int x = 0; x < 10; x++)
        {
            if(gameGridcol[x].row[y] != null)
            {
                return false;
            }
        }
        return true;
    }

}
