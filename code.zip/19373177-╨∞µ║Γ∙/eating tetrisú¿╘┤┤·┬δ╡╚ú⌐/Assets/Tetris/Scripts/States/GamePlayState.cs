﻿//   ********************************************************************************					  
//           XuJingyi    Email:2123373772@qq.com *										
//   ********************************************************************************
//玩游戏的状态
using UnityEngine;

public class GamePlayState : _StatesBase {

    private float gamePlayDuration; //间隔

	#region implemented abstract members of _StatesBase
	public override void OnActivate ()
	{
        Managers.UI.panel.SetActive(false);
        Managers.UI.ActivateUI(Menus.INGAME);

        gamePlayDuration = Time.time;
        Managers.Cam.ZoomIn(); 
        Debug.Log ("<color=green>Gameplay State</color> OnActive");	
	}
	public override void OnDeactivate ()
	{
        Managers.Game.stats.timeSpent += Time.time - gamePlayDuration; //统计时间
		Debug.Log ("<color=red>Gameplay State</color> OnDeactivate");
	}

	public override void OnUpdate ()
	{
        if (Managers.Game.snakeControl != null)
            Managers.Game.snakeControl.SnakeUpdate();
		Debug.Log ("<color=yellow>Gameplay State</color> OnUpdate");
	}
	#endregion

}
