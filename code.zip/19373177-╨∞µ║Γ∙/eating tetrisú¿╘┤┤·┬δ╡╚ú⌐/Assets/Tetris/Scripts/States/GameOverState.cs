﻿//游戏结束的状态
using UnityEngine;

public class GameOverState : _StatesBase {

	#region implemented abstract members of _StatesBase
	public override void OnActivate ()
	{
        Managers.Game.isGameActive = false; //关闭执行
        Managers.Game.stats.highScore = Managers.Score.currentScore;
        Managers.Game.stats.totalScore = Managers.Score.highScore;//统计分数
        Managers.Game.stats.numberOfGames++;  //统计玩游戏的次数
        Managers.UI.popUps.ActivateGameOverPopUp();
        Managers.Audio.PlayLoseSound();
       
        Debug.Log ("<color=green>Game Over State</color> OnActive");	
	}

	public override void OnDeactivate ()
    {
       // Managers.Adv.ShowRewardedAd();
        Debug.Log ("<color=red>Game Over State</color> OnDeactivate");
	}

	public override void OnUpdate ()
	{
		Debug.Log ("<color=yellow>Game Over State</color> OnUpdate");
	}
	#endregion

}
