﻿//总共有三种状态  能不能控制的状态
using UnityEngine;
using System.Collections;
//使用mono behaviour
//Awake：当一个脚本实例被载入时Awake被调用。我们大多在这个类中完成成员变量的初始化
//Start：仅在Update函数第一次被调用前调用。因为它是在Awake之后被调用的，我们可以把一些需要依赖Awake的变量放在Start里面初始化。 同时我们还大多在这个类中执行StartCoroutine进行一些协程的触发。要注意在用C#写脚本时，必须使用StartCoroutine开始一个协程，但是如果使用的是JavaScript，则不需要这么做。
//Update：当MonoBehaviour启用时，其Update在每一帧被调用。
public abstract class _StatesBase : MonoBehaviour
{ 

	public abstract void OnActivate();
	public abstract void OnDeactivate();
	public abstract void OnUpdate();  //更新

	public override string ToString()
	{
		return this.GetType().ToString();
	}
}
