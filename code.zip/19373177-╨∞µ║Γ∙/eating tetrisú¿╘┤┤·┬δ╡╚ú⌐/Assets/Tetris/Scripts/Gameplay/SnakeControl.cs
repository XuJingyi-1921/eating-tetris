﻿using UnityEngine;

public class SnakeControl : MonoBehaviour
{
    public float transitionInterval = 0.5f;
    public float fastTransitionInterval;
    private float lastFall = 0; //上一次下落的时间

    private bool isSnake = true; 
    
    public GameObject[] snakeBody = new GameObject[4]; //对蛇身体的引用
    //把蛇的身体四个格子放进这四个数组里

    // start是最早运行的
    void Start()
    {
        //是否合法 如果非法就直接执行游戏结束
        if (!Managers.Grid.IsValidGridPosition(this.transform))
        {
            Managers.Game.SetState(typeof(GameOverState)); //游戏分为 manu  gameplay  gameover三个状态
            Destroy(this.gameObject);//销毁掉
        }
    }

    public void SnakeUpdate() //判断蛇要移动还是下落
    {
        if (isSnake)
            SnakeMove();
        else
            FreeFall();
    }

    public void SnakeMove()
    {
        if (Time.time - lastFall >= transitionInterval) //按指定间隔时间移动
            //需要判断贪吃蛇方向 方向是用户输入的所以不方便写在这里 写在游戏的总管理类
        {
            Managers.Audio.PlayDropSound();
            for(int i = 3; i >= 1; i--)//蛇的移动，从后往前，到前一个身体的位置
            {
                snakeBody[i].transform.position = snakeBody[i-1].transform.position;
            }
            snakeBody[0].transform.position += Managers.Game.inputDir;
            Managers.Game.lastDir = Managers.Game.inputDir; //记录最后一次移动的方向

            //移动完之后判断是否和星星撞上
            if (snakeBody[0].transform.position == Managers.Game.currentStar.position)
            {
                EatStar();
                Managers.Grid.UpdateGrid(this.transform);//更新格子
            }

            //没吃到星星就是正常移动，分为合法移动和非法移动
            if (Managers.Grid.IsValidGridPosition(this.transform))
            {
                Managers.Grid.UpdateGrid(this.transform); //合法就更新格子
            }
            else //非法的话
            {
                Managers.Game.SetState(typeof(GameOverState)); //游戏分为 manu gameplay  gameover三个状态
                Destroy(this.gameObject);//销毁掉
            }
            lastFall = Time.time;
        }
    }
    //写一个吃星星的方法
    private void EatStar()
    {
        isSnake = false;//把他变成俄罗斯方块
        Destroy(Managers.Game.currentStar.gameObject); //吃完星星之后把星星销毁掉
        Managers.Score.OnScore(1);
        Managers.Audio.PlayDropSound(); //吃到星星给一分，然后播放坠落音效
        Managers.Input.isActive = false; //这样变成俄罗斯方块之后用户就不能动了
    }

    public void FreeFall() //俄罗斯方块下落代码
    {
        if (Time.time - lastFall >= fastTransitionInterval) //游戏运行到现在的时间减去上次下落的时间大于等于间隔
            //如果是大型游戏就不能这样  因为这里的 time.time不会特别大
        {
            // 调整位置
            transform.position += Vector3.down;
            Managers.Audio.PlayDropSound();

            // 是否合法
            if (Managers.Grid.IsValidGridPosition(this.transform))
            {
                // 合法就更新格子
                Managers.Grid.UpdateGrid(this.transform);
            }
            else
            {
                transform.position += new Vector3(0, 1, 0);

                GetComponent<SnakeControl>().enabled = false;
                Managers.Game.snakeControl = null;
                
                // 清除
                Managers.Grid.PlaceShape();
            }
            lastFall = Time.time; //把最后一下下落的时间记录下来
        }
    }

}
