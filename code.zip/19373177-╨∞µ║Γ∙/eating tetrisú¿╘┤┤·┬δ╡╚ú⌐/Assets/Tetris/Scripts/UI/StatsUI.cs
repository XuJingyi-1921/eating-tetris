﻿//statistics 数据界面
using UnityEngine;
using UnityEngine.UI;

public class StatsUI : MonoBehaviour { //记录分数 时间 玩的局数

    public Text highScore;
    public Text totalScore;
    public Text timeSpent;
    public Text numberOfGames;

    public void ClearStats()
    {
        Managers.Game.stats.ClearStats();
        RefreshText();
    }

    void OnEnable()
    {
        RefreshText();
    }

    void RefreshText()
    {
        highScore.text = Managers.Game.stats.highScore.ToString();
        totalScore.text = Managers.Game.stats.totalScore.ToString();
        timeSpent.text = TimeUtil.SecondsToHMS(Managers.Game.stats.timeSpent);
        numberOfGames.text = Managers.Game.stats.numberOfGames.ToString();
    }

}
