﻿//   ********************************************************************************					  
//   * XuJingyi      Email: 2123373772@qq.com							              *										
//   *********************************************************************************
//死了之后跳出来的
using UnityEngine;
using UnityEngine.UI;


public class GameOverPopUp : MonoBehaviour {

    public Text gameOverScore; //这一局的分数
    
    void OnEnable()
    {
        gameOverScore.text = Managers.Score.currentScore.ToString();
        Managers.UI.panel.SetActive(true); 
    }

    public void BackToMainMenu()
    {
        Managers.Grid.ClearBoard();// gridmanager里的 清楚格子
        Managers.Audio.PlayUIClick(); //点击声音
        Managers.UI.panel.SetActive(false);
        Managers.Game.SetState(typeof(MenuState)); //state从play转移到menu
        gameObject.SetActive(false); //不能移动了
    }
}
