﻿using UnityEngine; //数据按钮

public class PlayerStatsButton : MonoBehaviour
{
    public void OnClickPlayerStatsButton()
    {
        Managers.Audio.PlayUIClick();
        Managers.UI.popUps.ActivatePlayerStatsPopUp();
        Managers.UI.panel.SetActive(true);  //可以移动
    }
}
