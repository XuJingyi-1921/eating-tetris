﻿//home按钮
using UnityEngine;

public class ContinueButton : MonoBehaviour {

    public void OnClickContinueButton()
    {
        Managers.Score.ResetScore();
        Managers.Audio.PlayUIClick(); 
        Managers.Game.SetState(typeof(GamePlayState)); //进入初始的state
    }
}
