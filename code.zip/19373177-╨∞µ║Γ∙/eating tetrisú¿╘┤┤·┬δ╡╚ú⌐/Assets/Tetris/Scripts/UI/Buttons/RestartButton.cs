﻿//重新开始
using UnityEngine;

public class RestartButton : MonoBehaviour {

    public void OnClickRestartButton()
    {
        Managers.Score.ResetScore();  //分数 声音 记得重设分数 
        Managers.Audio.PlayUIClick();
        Managers.Grid.ClearBoard(); //清除格子
        Managers.Game.isGameActive = false;  
        Managers.Game.SetState(typeof(GamePlayState));  //到玩游戏state
        Managers.UI.inGameUI.gameOverPopUp.SetActive(false);
    }
}
