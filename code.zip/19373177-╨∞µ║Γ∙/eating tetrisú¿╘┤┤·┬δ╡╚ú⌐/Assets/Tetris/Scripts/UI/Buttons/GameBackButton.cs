﻿//继续游戏
using UnityEngine;

public class GameBackButton : MonoBehaviour {

	public void OnClickBackButton()
	{
        Managers.Audio.PlayUIClick();
        Managers.Game.SetState(typeof(MenuState)); //到主菜单界面
    }
}
