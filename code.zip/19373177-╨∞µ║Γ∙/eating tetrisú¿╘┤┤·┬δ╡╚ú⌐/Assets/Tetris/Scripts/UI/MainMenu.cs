﻿//   ********************************************************************************					  
//   * XuJingyi  email: 2123373772@qq.com								              *										
//   *********************************************************************************

using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class MainMenu : MonoBehaviour
{
    public Text tetrisLogoText; //LOGO
    public GameObject menuButtons; //展示菜单
    public GameObject restartButton;//重新开始

    public HorizontalLayoutGroup layout;

    void Awake()
    {
        layout = GetComponent<HorizontalLayoutGroup>();
    }

    void OnEnable()
	{
        tetrisLogoText.enabled = true;
        menuButtons.SetActive (true);   
    }

	void OnDisable()
	{
		tetrisLogoText.enabled = false;
		menuButtons.SetActive (false); 
    }

    public void DisableMenuButtons ()
	{
		menuButtons.SetActive (false);
	}

    public void MainMenuStartAnimation()
    {
        menuButtons.GetComponent<RectTransform>().DOAnchorPosY(-850, 1, true);
        tetrisLogoText.GetComponent<RectTransform>().DOAnchorPosY(600, 1, true);
    }

    public void MainMenuEndAnimation()
    {
        menuButtons.GetComponent<RectTransform>().DOAnchorPosY(-1450, 0.3f, true);
        tetrisLogoText.GetComponent<RectTransform>().DOAnchorPosY(1200, 0.3f, true);
    }


}

