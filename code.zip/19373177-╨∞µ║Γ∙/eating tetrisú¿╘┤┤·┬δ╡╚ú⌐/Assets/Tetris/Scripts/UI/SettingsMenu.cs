﻿//设置界面  声音 微博 微信 推特等
using UnityEngine;

public class SettingsMenu : MonoBehaviour
{
    public GameObject soundCross;

    public void TurnUpDownSound() 
    {
        if (AudioListener.volume == 0)
        {
            soundCross.SetActive(false);
            AudioListener.volume = 1.0f;
            Managers.Audio.PlayUIClick();
        }
        else if (AudioListener.volume == 1.0f)
        {
            soundCross.SetActive(true);
            AudioListener.volume = 0f;
        }
    }

    public void OpenWeiboPage()
    {
        Application.OpenURL(Constants.WEIBO_URL);
    }

    public void OpenTwitterPage()
    {
        Application.OpenURL(Constants.TWITTER_URL);
    }

    public void OpenContact()
    {
        Application.OpenURL(Constants.CONTACT_URL);
    }

    public void RateAsset()
    {
        Application.OpenURL(Constants.ASSETSTORE_URL);
    }
}
