﻿//记录各种网站   都是常量
public static class Constants
{
    public static string GAME_NAME = "Tetris";
    public static string ASSETSTORE_URL = "https://www.weibo.com/u/5838543275/home?topnav=1&wvr=6&mod=logo";
    public static string ONLINE_DOC_URL = "https://goo.gl/pekuTQ";
    public static string PATREON_URL = "www.4399.com";
    public static string WEIBO_URL = "https://wx.qq.com/";
    public static string TWITTER_URL = "https://twitter.com/home";
    public static string CONTACT_URL = "www.4399.com";
    public static int CURRENT_ROW = 16;
}
